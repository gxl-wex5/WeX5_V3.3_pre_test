﻿//-----------------------------------------------------------------------
// <copyright file="Program.cs" company="Qibu">
// Copyright (c) Qibu Enterprises. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

using System.IO;

namespace BuildBaasASPServer
{
    using System;
    using System.Collections.Generic;

    /// <summary>
    /// Main program class.
    /// </summary>
    public class Program
    {
        /// <summary>
        /// Main program entry.
        /// </summary>
        /// <param name="args">
        /// First parameter is asp.net solution path.
        /// Second parameter is visual studio installed path.
        ///      For example: BuildBaasASPServer E:\ZJY\X5BaasService "C:\Program Files(x86)\Microsoft Visual Studio 14.0"
        /// </param>
        public static void Main(string[] args)
        {
            if (args.Length != 1)
            {
                Console.WriteLine("First parameter is asp.net solution path.");
                Console.WriteLine(@"    For example: BuildBaasASPServer E:\ZJY\X5BaasService");
                return;
            }

            var handleResult = new CsProjectReaderAndHandle().Handle(args[0]);

            if (!handleResult)
            {
                throw new Exception("Handle project configure file failed.");
            }

            Console.WriteLine("Add csharp files to project success!");

            var tempDir = Directory.GetDirectoryRoot(args[0]);
            string driver = String.Empty;
            if (!string.IsNullOrEmpty(tempDir) && tempDir.Length == 3)
            {
                driver = tempDir.Substring(0, 2);
            }
            else
            {
                throw new Exception("Cannot get driver from parameter: {0}." + args[0]);
            }

            var cmdList = new List<string>();
            cmdList.Add(@"cd " + args[0]);
            cmdList.Add(driver);
            cmdList.Add(@"msbuild X5BaasService.sln /p:Configuration=Release;DeployOnbuild=true;PublishProfile=""Publish Demo""");
            cmdList.Add("exit");

            new WinCommand().Run(cmdList);

            Console.WriteLine("Compile and publish project success!");
            //// Console.ReadKey();
        }
    }
}
