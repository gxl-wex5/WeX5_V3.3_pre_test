﻿//-----------------------------------------------------------------------
// <copyright file="WinCommand.cs" company="Qibu">
// Copyright (c) Qibu Enterprises. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace BuildBaasASPServer
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;

    /// <summary>
    /// Window command running container.
    /// </summary>
    public class WinCommand
    {
        /// <summary>
        /// Run command list.
        /// </summary>
        /// <param name="commandList">Command list</param>
        public void Run(List<string> commandList)
        {
            var cmd = new Process
            {
                StartInfo =
                {
                    FileName = "cmd.exe",
                    RedirectStandardInput = true,
                    RedirectStandardOutput = true,
                    CreateNoWindow = true,
                    UseShellExecute = false
                }
            };
            cmd.OutputDataReceived += OutputHandler;
            cmd.Start();

            foreach (var command in commandList)
            {
                cmd.StandardInput.WriteLine(command);
            }

            cmd.BeginOutputReadLine();
            cmd.WaitForExit();
            cmd.Close();
        }

        /// <summary>
        /// Display result of command running.
        /// </summary>
        /// <param name="sendingProcess">Send process</param>
        /// <param name="outLine">Output line</param>
        private static void OutputHandler(object sendingProcess, DataReceivedEventArgs outLine)
        {
            if (!string.IsNullOrEmpty(outLine.Data))
            {
                Console.WriteLine(outLine.Data);
            }
        }
    }
}
