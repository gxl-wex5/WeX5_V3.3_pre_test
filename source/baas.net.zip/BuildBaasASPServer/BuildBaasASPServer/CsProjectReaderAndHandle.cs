﻿//-----------------------------------------------------------------------
// <copyright file="CsProjectReaderAndHandle.cs" company="Qibu">
// Copyright (c) Qibu Enterprises. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace BuildBaasASPServer
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Xml;

    /// <summary>
    /// Add auto generate cs files to current project configure file(XML file).
    /// </summary>
    public class CsProjectReaderAndHandle
    {
        /// <summary>
        /// XML node record need to compile file's name.
        /// </summary>
        private XmlNode compileNode;

        /// <summary>
        /// Project path.
        /// </summary>
        private string projectPath;

        /// <summary>
        /// The project configuration file path and name.
        /// </summary>
        private string projectConfigurationFile;

        /// <summary>
        /// Add cs file's name to project configure file.
        /// </summary>
        /// <param name="targetProjectPath">Target project path</param>
        /// <returns>Handle result</returns>
        public bool Handle(string targetProjectPath)
        {
            var doc = new XmlDocument();
            this.projectPath = targetProjectPath;

            var files = Directory.GetFiles(targetProjectPath, "*.csproj", SearchOption.AllDirectories);

            if (string.IsNullOrEmpty(targetProjectPath))
            {
                throw new Exception("The specified project path cannot be empty or null");
            }

            if (files.Length == 0)
            {
                throw new Exception("The sharp project exits in specified project path.");
            }

            this.projectConfigurationFile = files[0];
            doc.Load(projectConfigurationFile);

            this.LoadNodesFromXml(ref doc);

            var fileList = this.FindAllFile(@"\X5BaasService\justep");

            this.AddFileList(fileList, ref doc);

            return true;
        }

        /// <summary>
        /// Read compile XML node from XML document.
        /// </summary>
        /// <param name="doc">Xml document</param>
        private void LoadNodesFromXml(ref XmlDocument doc)
        {
            var root = doc.DocumentElement;
            if (root != null)
            {
                var nodeList = root.ChildNodes;
                foreach (XmlNode node in nodeList)
                {
                    if (node.Name == "ItemGroup")
                    {
                        if (node.ChildNodes.Count > 0)
                        {
                            if (node.ChildNodes[0].Name == "Compile")
                            {
                                compileNode = node;
                            }
                        }
                    }
                }
            }
        }

        /// <summary>
        /// Add files to compile node.
        /// </summary>
        /// <param name="filesList">Excluded files</param>
        /// <param name="doc">Xml document</param>
        private void AddFileList(IEnumerable<string> filesList, ref XmlDocument doc)
        {
            var hasFiles = new List<string>();
            var needAddFiles = new List<string>();

            foreach (XmlNode node in compileNode.ChildNodes)
            {
                if (node.Attributes != null)
                {
                    hasFiles.Add(node.Attributes[0].Value);
                }
            }

            foreach (var fileName in filesList)
            {
                if (!hasFiles.Contains(fileName))
                {
                    needAddFiles.Add(fileName);
                }
            }

            // Add node exampel:<Compile Include="Action\ActionContext.cs" />
            foreach (var fileName in needAddFiles)
            {
                if (doc.DocumentElement != null)
                {
                    XmlNode compileSubNode = doc.CreateElement("Compile", doc.DocumentElement.NamespaceURI);
                    XmlAttribute include = doc.CreateAttribute("Include");
                    include.Value = fileName;
                    compileSubNode.Attributes?.Append(include);

                    compileNode.AppendChild(compileSubNode);
                }
            }

            doc.Save(projectConfigurationFile);
        }

        /// <summary>
        /// Find all file included project path.
        /// </summary>
        /// <param name="subPath">Project sub path</param>
        /// <returns>Files list</returns>
        private IEnumerable<string> FindAllFile(string subPath)
        {
            var filesList = new List<string>();
            if (!Directory.Exists(projectPath + subPath))
            {
                throw new Exception(projectPath + subPath +" path is not exists!");
            }

            var folder = new DirectoryInfo(projectPath + subPath);

            foreach (var fileInfo in folder.GetFiles())
            {
                if (fileInfo.Extension == ".cs")
                {
                    var relativePath = fileInfo.FullName.Substring(this.projectPath.Length + 1);
                    relativePath = relativePath.Substring(relativePath.IndexOf("\\", StringComparison.Ordinal) + 1);
                    filesList.Add(relativePath);
                }
            }

            return filesList;
        }
    }
}
