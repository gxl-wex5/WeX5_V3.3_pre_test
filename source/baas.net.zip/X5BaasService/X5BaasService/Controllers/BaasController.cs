﻿using System;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Com.Justep.Baas.Action;
using Com.Justep.Baas.Comm;
using Com.Justep.Baas.Data;
using Newtonsoft.Json.Linq;

namespace Com.Justep.Controllers
{
    using JSONObject = JObject;

    public class BaasController : Controller
    {
        private const string MethodPost = "POST";
        private const string MultipartContentType = "multipart/form-data";
        private string accessControlAllowOrigin = "*";

        // GET: Baas
        public void Justep()
        {
            try
            {
                var request = System.Web.HttpContext.Current.Request;
                var response = System.Web.HttpContext.Current.Response;

                switch (request.HttpMethod)
                {
                    case MethodPost:
                    case "GET":
                        ExecService(System.Web.HttpContext.Current.Request, System.Web.HttpContext.Current.Response);
                        break;

                    // 设置跨域访问支持
                    case "OPTIONS":
                        if (!string.IsNullOrEmpty(accessControlAllowOrigin))
                        {
                            response.AddHeader("P3P", "CP=CAO PSA OUR");
                            response.AddHeader("Access-Control-Allow-Origin", accessControlAllowOrigin);
                            response.AddHeader("Access-Control-Allow-Credentials", "true");
                            response.AddHeader("Access-Control-Allow-Methods", request.Headers["Access-Control-Request-Method"]);
                            response.AddHeader("Access-Control-Allow-Headers", request.Headers["Access-Control-Request-Headers"]);
                        }
                        return;

                    default:
                        return;
                }
            }
            catch (Exception e)
            {
                Console.Write(e.StackTrace);
            }
        }

        private static String GetRequestContentType(HttpRequest request)
        {
            return request.ContentType;
        }

        private static bool IsRequestMultipart(String type)
        {
            return !string.IsNullOrEmpty(type) && -1 < type.IndexOf(MultipartContentType, StringComparison.Ordinal);
        }

        private static bool IsRequestMultipart(HttpRequest request)
        {
            return IsRequestMultipart(GetRequestContentType(request));
        }

        private void ExecService(HttpRequest request, HttpResponse response)
        {
            var reg = request;
            JSONObject paramObject = GetParams(reg);
            JSONObject ret = Engine.ExecAction(reg.Path, paramObject);
            if (null != ret)
            {
                //设置跨域访问
                if (!string.IsNullOrEmpty(accessControlAllowOrigin))
                {
                    response.AddHeader("P3P", "CP=CAO PSA OUR");
                    response.AddHeader("Access-Control-Allow-Origin", accessControlAllowOrigin);
                    response.AddHeader("Access-Control-Allow-Credentials", "true");
                }
                Util.WriteJsonToResponse(response, ret);
            }
        }

        private JSONObject GetParams(Stream inputStream)
        {
            byte[] buffer = StreamToBytes(inputStream);
            var bodyData = StringHelperClass.NewString(buffer.ToArray(), "UTF-8");

            return inputStream.Length == 0 ? JSONObject.Parse("{}") : JSONObject.Parse(bodyData);
        }
        public byte[] StreamToBytes(Stream stream)
        {
            byte[] bytes = new byte[stream.Length];
            stream.Read(bytes, 0, bytes.Length);
            // 设置当前流的位置为流的开始   
            stream.Seek(0, SeekOrigin.Begin);
            return bytes;
        }

        private JSONObject GetParams(HttpRequest request)
        {
            String method = request.HttpMethod;
            JSONObject paramObject;
            if (IsRequestMultipart(request))
            {
                paramObject = new JSONObject();
                return paramObject;
            }

            if (MethodPost == method)
            {
                return GetParams(request.InputStream);
            }

            paramObject = new JSONObject();
            foreach (var k in request.Params.AllKeys)
            {
                var key = k;
                paramObject.Add(key, request.Params[key]);
            }
            return paramObject;
        }
    }
}