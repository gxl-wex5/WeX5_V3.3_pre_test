﻿using System.Web.Mvc;
using System.Web.Routing;

namespace Com.Justep.Baas
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
                //namespaces: new[] { "Com.Justep.Baas.Controllers" }
            );

            routes.MapRoute(
                name: "BaasServer",
                url: "{controller}/{action}/{classname}/{operation}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
                //namespaces: new[] { "Com.Justep.Baas.Controllers" }
            );
        }
    }
}
