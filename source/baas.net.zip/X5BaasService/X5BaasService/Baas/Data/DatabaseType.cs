﻿using System;
using System.Data.Common;

namespace Com.Justep.Baas.Data
{
    /// <summary>
    /// 数据库类型枚举，可以扩展以支持其他类型的数据库及驱动
    /// </summary>
    public enum DatabaseType
    {
        Mssql, Oracle, MySql
    }

    /// <summary>
    /// 数据库类型枚举辅助类，用于获取数据库类型，获取SQL参数前缀
    /// </summary>
    public static class DatabaseTypeHelper
    {
        /// <summary>
        /// 从数据库连接判断数据库类型
        /// </summary>
        public static DatabaseType GetDatabaseType(DbConnection conn)
        {
            if (IsMysql(conn))
            {
                return DatabaseType.MySql;
            }
            else if (IsOracle(conn))
            {
                return DatabaseType.Oracle;
            }
            else
            {
                return DatabaseType.Mssql;
            }
        }

        private static bool IsMysql(DbConnection conn)
        {
            return conn.ToString().ToUpper().IndexOf("MYSQL", StringComparison.Ordinal) != -1;
        }

        private static bool IsOracle(DbConnection conn)
        {
            return conn.ToString().ToUpper().IndexOf("ORACLE", StringComparison.Ordinal) != -1;
        }

        /// <summary>
        /// 获取SQL参数前缀
        /// </summary>
        public static char GetParamPrefix(DbConnection conn)
        {
            DatabaseType type = GetDatabaseType(conn);
            return GetParamPrefix(type);
        }

        /// <summary>
        /// 获取SQL参数前缀
        /// </summary>
        public static char GetParamPrefix(DatabaseType type)
        {
            switch (type)
            {
                case DatabaseType.MySql: return '?';
                case DatabaseType.Oracle: return ':';
                default: return '@';
            }
        }
    }
}