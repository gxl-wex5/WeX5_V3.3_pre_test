﻿namespace Com.Justep.Baas.Data
{
    /// <summary>
    /// Table中的列值对象，包含当前值、旧值、是否改变三个数据域
    /// </summary>
    public class ColumnValue
    {
        private object value = null;
        private object oldValue = null;
        private bool changed = false;

        public ColumnValue(object value)
        {
            this.value = value;
        }

        public ColumnValue(object value, object oldValue, bool changed)
        {
            this.value = value;
            this.oldValue = oldValue;
            this.changed = changed;
        }

        public virtual object Value
        {
            get
            {
                return value;
            }
        }

        public virtual object OldValue
        {
            get
            {
                return oldValue;
            }
        }

        public virtual bool Changed
        {
            get
            {
                return changed;
            }
        }

    }

}