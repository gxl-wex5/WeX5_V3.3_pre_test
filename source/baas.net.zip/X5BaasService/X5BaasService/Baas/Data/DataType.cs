﻿using System;
using System.Collections.Generic;

namespace Com.Justep.Baas.Data
{

    /// <summary>
    /// Table的数据类型枚举
    /// </summary>
    public enum DataType
    {
        STRING, INTEGER, LONG, FLOAT, DOUBLE, DECIMAL, BOOLEAN, DATE, TIME, DATETIME
    }

    /// <summary>
    /// Table的数据类型枚举辅助类，用于类型转换
    /// </summary>
    public static class DataTypeHelper
    {
        private static Dictionary<DataType, string> dict = new Dictionary<DataType, string>();

        static DataTypeHelper()
        {
            dict.Add(DataType.STRING, "String");
            dict.Add(DataType.INTEGER, "Integer");
            dict.Add(DataType.LONG, "Long");
            dict.Add(DataType.FLOAT, "Float");
            dict.Add(DataType.DOUBLE, "Double");
            dict.Add(DataType.DECIMAL, "Decimal");
            dict.Add(DataType.BOOLEAN, "Boolean");
            dict.Add(DataType.DATE, "Date");
            dict.Add(DataType.TIME, "Time");
            dict.Add(DataType.DATETIME, "DateTime");
        }

        public static DataType Parse(string str)
        {
            return Util.IsEmptyString(str) ? DataType.STRING : (DataType)Enum.Parse(typeof(DataType), str.ToUpper());
        }

        public static string ToString(DataType dataType)
        {
            return dict[dataType];
        }

        public static DataType ParseSQLType(Type sqlType)
        {
            switch (sqlType.ToString())
            {
                case "System.String":
                    return DataType.STRING;
                case "System.Byte":
                case "System.SByte":
                case "System.Int16":
                case "System.UInt16":
                case "System.Int32":
                case "System.UInt32":
                    return DataType.INTEGER;
                case "System.Int64":
                case "System.UInt64":
                    return DataType.LONG;
                case "System.Single":
                    return DataType.FLOAT;
                case "System.Double":
                    return DataType.DOUBLE;
                case "System.Decimal":
                    return DataType.DECIMAL;
                case "System.Boolean":
                    return DataType.BOOLEAN;
                case "System.TimeSpan":
                    return DataType.TIME;
                case "System.DateTime":
                    return DataType.DATETIME;
                default:
                    return DataType.STRING;
            }
        }
    }

}