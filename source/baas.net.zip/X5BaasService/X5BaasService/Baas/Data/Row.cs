﻿using System;
using System.Collections.Generic;

namespace Com.Justep.Baas.Data
{
    /// <summary>
    /// Table中的行对象，包含行状态和列值数据域
    /// </summary>
    public class Row
    {
        private RowState state = RowState.NONE;
        private IDictionary<string, ColumnValue> values = new Dictionary<string, ColumnValue>();

        public Row(IDictionary<string, ColumnValue> values, RowState state)
        {
            this.values.AddRange(values);
            this.state = state;
        }

        public virtual RowState State
        {
            get
            {
                return state;
            }
        }

        public virtual ColumnValue GetColumnValue(string column)
        {
            return values.ContainsKey(column) ? values[column] : null;
        }

        public virtual object GetValue(string column)
        {
            return GetColumnValue(column).Value;
        }

        public virtual object GetOldValue(string column)
        {
            return GetColumnValue(column).OldValue;
        }

        public virtual bool IsChanged(string column)
        {
            return GetColumnValue(column).Changed;
        }

        public virtual string GetString(string column)
        {
            return (string)GetValue(column);
        }

        public virtual int? GetInteger(string column)
        {
            return (int?)GetValue(column);
        }

        public virtual float? GetFloat(string column)
        {
            return (float?)GetValue(column);
        }

        public virtual decimal? GetDecimal(string column)
        {
            return (decimal?)GetValue(column);
        }

        public virtual bool? GetBoolean(string column)
        {
            return (bool?)GetValue(column);
        }

        public virtual DateTime? GetDate(string column)
        {
            return (DateTime?)GetValue(column);
        }

        public virtual DateTime? GetTime(string column)
        {
            return (DateTime?)GetValue(column);
        }

        public virtual DateTime? GetDateTime(string column)
        {
            return (DateTime?)GetValue(column);
        }
    }


}