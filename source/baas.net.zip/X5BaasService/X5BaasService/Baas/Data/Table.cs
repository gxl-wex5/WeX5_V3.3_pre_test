﻿using System.Collections.Generic;

namespace Com.Justep.Baas.Data
{
    /// <summary>
    /// Table对象，包含元信息（列定义、ID列、总行数、行偏移）和行数据
    /// </summary>
	public class Table
    {
        private IDictionary<string, DataType> columns = new SortedDictionary<string, DataType>();
        private string idColumn = null;
        private int? total = null;
        private int? offset = null;

        private IList<Row> rows = new List<Row>();

        public Table(IDictionary<string, DataType> columns)
        {
            this.columns.AddRange(columns);
        }

        public virtual ICollection<string> ColumnNames
        {
            get
            {
                return columns.Keys;
            }
        }

        public virtual ICollection<DataType> ColumnTypes
        {
            get
            {
                return columns.Values;
            }
        }

        public virtual DataType GetColumnType(string column)
        {
            return columns[column];
        }

        public virtual void AppendRow(Row row)
        {
            rows.Add(row);
        }

        public virtual void AppendRows(ICollection<Row> rows)
        {
            foreach (Row row in rows)
            {
                AppendRow(row);
            }
        }

        public virtual IList<Row> Rows
        {
            get
            {
                return rows;
            }
        }

        public virtual ICollection<Row> GetRows(RowState state)
        {
            IList<Row> result = new List<Row>();
            foreach (Row row in rows)
            {
                if (state.Equals(row.State))
                {
                    result.Add(row);
                }
            }
            return result;
        }

        public virtual string IDColumn
        {
            get
            {
                return idColumn;
            }
            set
            {
                this.idColumn = value;
            }
        }


        public virtual int? Total
        {
            get
            {
                return total;
            }
            set
            {
                this.total = value;
            }
        }


        public virtual int? Offset
        {
            get
            {
                return offset;
            }
            set
            {
                this.offset = value;
            }
        }


    }

}