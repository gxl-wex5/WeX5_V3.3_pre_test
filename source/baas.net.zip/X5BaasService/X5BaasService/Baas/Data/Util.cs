﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Web;

namespace Com.Justep.Baas.Data
{
	using JSONObject = Newtonsoft.Json.Linq.JObject;

	public static class Util
	{
		/// <summary>
		/// 扩展IDictionay，增加addRange
		/// </summary>
		public static IDictionary<TKey, TValue> AddRange<TKey, TValue>(this IDictionary<TKey, TValue> self, IDictionary<TKey, TValue> source)
		{
			foreach (var item in source)
			{
				self[item.Key] = item.Value;
			}
			return self;
		}

		/// <summary>
		/// 将一个数组连接为格式化字符串 
		/// </summary>
		/// <param name="values"> </param>
		/// <param name="format"> 对数组元素的格式化，例如：'{0}'为每个数组元素增加单引号、({0} = ?)将每个数组元素格式化为括号中等于问号 </param>
		/// <param name="separator"> 分隔符，例如：,、OR、AND </param>
		public static string ArrayJoin(Array values, string format, string separator)
		{
			StringBuilder buf = new StringBuilder();
			foreach (object o in values)
			{
				if (buf.Length > 0)
				{
					buf.Append(separator);
				}
				buf.Append(string.Format(format, o.ToString()));
			}
			return buf.ToString();
		}

		/// <summary>
		/// 判断是否空字符串 
		/// </summary>
		public static bool IsEmptyString(string s)
		{
			return s == null || s.Trim().Length == 0;
		}

		public static DbParameter createParameterByCommand(DbCommand comm, string name, object value)
		{
			DbParameter param = comm.CreateParameter();
			param.ParameterName = name;
			param.Value = value;
			return param;
		}

		public static DbParameter createParameterByConnection(DbConnection conn, string name, object value)
		{
			return createParameterByCommand(conn.CreateCommand(), name, value);
		}

		/// <summary>
		/// SQL数据查询，转换返回Table，支持分页。
		/// </summary>
		/// <param name="parameters"> SQL中问号对应的参数值，按顺序匹配 </param>
		/// <param name="columns"> 列定义，对应前端JS中的Baas.getDataColumns(data) </param>
		/// <param name="offset"> 偏移行，null则不分页 </param>
		/// <param name="limit"> 行数，null则不分页 </param>
		public static Table QueryData(DbConnection conn, string sql, ICollection<DbParameter> parameters, object columns, int? offset, int? limit)
		{
			DatabaseType databaseType = DatabaseTypeHelper.GetDatabaseType(conn);

			// 数据库SQL分页处理
			bool needPaging = limit != null && offset != null;
			bool canPagingBySQL = true;
			if (needPaging)
			{
				if (DatabaseType.MySql.Equals(databaseType))
				{
					sql += " LIMIT " + offset + "," + limit;
				}
				else if (DatabaseType.Oracle.Equals(databaseType))
				{
					sql = string.Format("SELECT * FROM (SELECT rownum x5_bass_num_, x5_bass_main_.* FROM ({0}) x5_bass_main_ WHERE rownum <= {1:D}) WHERE x5_bass_num_ > {2:D}", sql, offset + limit, offset);
				}
				else
				{
					canPagingBySQL = false;
				}
			}

			// 数据查询
			DbCommand command = conn.CreateCommand();
			command.CommandText = sql;
			if (parameters != null)
			{
				command.Parameters.AddRange(parameters.ToArray());
			}
			System.Data.IDataReader rs = command.ExecuteReader();
			try
			{
				// 如果不能用SQL分页则滚动到指定行偏移
				if (needPaging && !canPagingBySQL)
				{
					for (int i = 0; i < offset; i++)
					{
						if (!rs.Read()) break;
					}
				}
				// 创建Table
				Table table = null;
				if (columns is JObject)
				{
					table = Transform.CreateTableByColumnsDefine((JObject)columns);
				}
				else
				{
					table = Transform.CreateTableByData(rs, (string)columns);
				}
				// 加载数据
				Transform.LoadRowsFromData(table, rs, limit);

				return table;
			}
			finally
			{
				rs.Close();
			}
		}

		/// <summary>
		/// 单表数据查询，转换返回Table，支持分页。
		/// </summary>
		/// <param name="tableName"> 表名 </param>
		/// <param name="columns"> 列定义，对应前端JS中的Baas.getDataColumns(data) </param>
		/// <param name="filters"> 过滤条件列表，SQL的Where部分 </param>
		/// <param name="orderBy"> SQL的Order By部分 </param>
		/// <param name="parameters"> SQL中问号对应的参数值列表 </param>
		/// <param name="offset"> 偏移行 </param>
		/// <param name="limit"> 行数 </param>
		public static Table QueryData(DbConnection conn, string tableName, object columns, ICollection<string> filters, string orderBy, ICollection<DbParameter> parameters, int? offset, int? limit)
		{
			string format = "SELECT {0} FROM {1} {2} {3} ";

			// 构造Where
			string where = (filters != null && filters.Count > 0) ? " WHERE " + Util.ArrayJoin(filters.ToArray(), "({0})", " AND ") : "";
			// 构造Order By
			orderBy = IsEmptyString(orderBy) ? "" : " ORDER BY " + orderBy;

			// 构造SQL
			string sql = string.Format(format, "*", tableName, where, orderBy);

			Table table = QueryData(conn, sql.ToString(), parameters, columns, offset, limit);
			// 如果是第一页，则返回总行数
			if (offset != null && offset.Equals(0))
			{
				string sqlTotal = string.Format(format, "COUNT(*)", tableName, where, "");
				object total = Util.GetValueBySQL(conn, sqlTotal.ToString(), parameters);
				table.Total = int.Parse(total.ToString());
			}
			return table;
		}

		/// <summary>
		/// 执行SQL查询，返回第一行第一列的值 
		/// </summary>
		public static object GetValueBySQL(DbConnection conn, string sql, ICollection<DbParameter> parameters)
		{
			DbCommand command = conn.CreateCommand();
			command.CommandText = sql;
			if (parameters != null)
			{
				command.Parameters.AddRange(parameters.ToArray());
			}
			return command.ExecuteScalar();
		}

		/// <summary>
		/// 保存Table数据，自动产生并执行基于WhereKey规则的增删改SQL语句 </summary>
		/// <param name="tableName"> 数据库表名 </param>
		public static void SaveData(DbConnection conn, Table table, string tableName)
		{
			SaveData(conn, table, tableName, "");
		}

		/// <summary>
		/// 保存Table数据，并指定列范围 
		/// </summary>
		/// <param name="tableName"> 数据库表名 </param>
		/// <param name="columns"> 列范围，以逗号分隔 </param>
		public static void SaveData(DbConnection conn, Table table, string tableName, string columns)
		{
			SaveData(conn, table, tableName, IsEmptyString(columns) ? null : columns.Split(','));
		}

		/// <summary>
		/// 保存Table数据，并指定列范围 
		/// </summary>
		/// <param name="tableName"> 数据库表名 </param>
		/// <param name="columns"> 列范围 </param>
		public static void SaveData(DbConnection conn, Table table, string tableName, ICollection<string> columns)
		{
			char sqlParamPrefix = DatabaseTypeHelper.GetParamPrefix(conn);

			string idColumn = table.IDColumn;
			columns = columns == null ? table.ColumnNames : columns;

			{
				DbCommand newCommand = conn.CreateCommand();
				newCommand.CommandText = CreateNewSQL(table, tableName, columns, sqlParamPrefix);
				foreach (Row row in table.GetRows(RowState.NEW))
				{
					newCommand.Parameters.Clear();
					newCommand.Parameters.AddRange(createNewParameters(newCommand, row, columns).ToArray());
					newCommand.ExecuteNonQuery();
				}
			}

			{
				DbCommand updateCommand = conn.CreateCommand();
				updateCommand.CommandText = CreateUpdateSQL(table, tableName, columns, sqlParamPrefix);
				foreach (Row row in table.GetRows(RowState.EDIT))
				{
					updateCommand.Parameters.Clear();
					updateCommand.Parameters.AddRange(createUpdateParameters(updateCommand, row, columns, idColumn).ToArray());
					updateCommand.ExecuteNonQuery();
				}
			}

			{
				DbCommand deleteCommand = conn.CreateCommand();
				deleteCommand.CommandText = CreateDeleteSQL(table, tableName, sqlParamPrefix);
				foreach (Row row in table.GetRows(RowState.DELETE))
				{
					deleteCommand.Parameters.Clear();
					deleteCommand.Parameters.AddRange(createDeleteParameters(deleteCommand, row, idColumn).ToArray());
					deleteCommand.ExecuteNonQuery();
				}
			}
		}

        /// <summary>
        /// 输出JSON
        /// </summary>
        /// <param name="response">Http response</param>
        /// <param name="json">Response content</param>
        public static void WriteJsonToResponse(HttpResponse response, JSONObject json)
		{
			response.ContentType = "text/html;charset=utf-8";
			/* 放开下面注释的代码就可以支持跨域
			if (response instanceof javax.servlet.http.HttpServletResponse) {
				// "*"表明允许任何地址的跨域调用，正式部署时应替换为正式地址
				((javax.servlet.http.HttpServletResponse) response).addHeader("Access-Control-Allow-Origin", "*"); 
			}
			 */
			response.Write(json.ToString());
		}

		private static string CreateNewSQL(Table table, string tableName, ICollection<string> columns, char sqlParamPrefix)
		{
			StringBuilder sql = new StringBuilder();
			sql.Append("INSERT INTO " + tableName);
			sql.Append(" (" + ArrayJoin(columns.ToArray(), "{0}", ",") + ") ");
			sql.Append(" VALUES (" + ArrayJoin(columns.ToArray(), sqlParamPrefix + "{0}", ",") + ") ");
			return sql.ToString();
		}

		private static ICollection<DbParameter> createNewParameters(DbCommand comm, Row row, ICollection<string> columns)
		{
			ICollection<DbParameter> parameters = new List<DbParameter>();

			foreach (string column in columns)
			{
				parameters.Add(createParameterByCommand(comm, column, row.GetValue(column)));
			}
			return parameters;
		}

		private static string CreateUpdateSQL(Table table, string tableName, ICollection<string> columns, char sqlParamPrefix)
		{
			StringBuilder sql = new StringBuilder();
			sql.Append("UPDATE " + tableName);
			sql.Append(" SET " + ArrayJoin(columns.ToArray(), "{0} = " + sqlParamPrefix + "{0}", ","));
			sql.Append(" WHERE " + table.IDColumn + " = " + sqlParamPrefix + table.IDColumn);
			return sql.ToString();
		}

		private static ICollection<DbParameter> createUpdateParameters(DbCommand comm, Row row, ICollection<string> columns, string idColumn)
		{
			ICollection<DbParameter> parameters = new List<DbParameter>();

			parameters.Add(createParameterByCommand(comm, idColumn, row.IsChanged(idColumn) ? row.GetOldValue(idColumn) : row.GetValue(idColumn)));
			foreach (string column in columns)
			{
				if (idColumn.Equals(column)) continue;
				parameters.Add(createParameterByCommand(comm, column, row.GetValue(column)));
			}

			return parameters;
		}

		private static string CreateDeleteSQL(Table table, string tableName, char sqlParamPrefix)
		{
			StringBuilder sql = new StringBuilder();
			sql.Append("DELETE FROM " + tableName);
			sql.Append(" WHERE " + table.IDColumn + " = " + sqlParamPrefix + table.IDColumn);
			return sql.ToString();
		}

		private static ICollection<DbParameter> createDeleteParameters(DbCommand comm, Row row, string idColumn)
		{
			ICollection<DbParameter> parameters = new List<DbParameter>();
			parameters.Add(createParameterByCommand(comm, idColumn, row.IsChanged(idColumn) ? row.GetOldValue(idColumn) : row.GetValue(idColumn)));
			return parameters;
		}

	}

}