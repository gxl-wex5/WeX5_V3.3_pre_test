﻿using System;
using System.Runtime.Remoting;

namespace Com.Justep.Baas.Comm
{
    public class BaasException : ServerException
    {
        public BaasException(string msg):base(msg)
        {
            
        }

        public BaasException(string msg, Exception exception):base(msg,exception)
        {

        }
    }
}