﻿using System;
using Newtonsoft.Json.Linq;

/// <summary>
/// Summary description for JsonHelperClass
/// </summary>
public static class JsonHelperClass
{
    public static string GetString(this JObject self, string keyName)
    {
        if (self[keyName] != null)
        {
            return self.GetValue(keyName).ToString();
        }
        return null;
    }

    public static int? GetInt(this JObject self, string keyName)
    {
        if (self[keyName] != null)
        {
            return int.Parse(self[keyName].ToString());
        }
        return null;
    }
}