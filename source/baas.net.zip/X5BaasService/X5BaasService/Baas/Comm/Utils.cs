﻿using System;
using System.Text;

namespace Com.Justep.Baas.Comm
{
    public class Utils
    {
        public static string GetLineSep()
        {
            return "\n";
        }

        public static void check(bool isOK, Object msg1)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException("" + msg1);
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5, Object msg6)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5, msg6));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5, Object msg6, Object msg7)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5, msg6, msg7));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5, Object msg6, Object msg7, Object msg8)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5, msg6, msg7, msg8));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5, Object msg6, Object msg7, Object msg8,
                Object msg9)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9));
                throw exp;
            }
        }

        public static void check(bool isOK, Object msg1, Object msg2, Object msg3, Object msg4, Object msg5, Object msg6, Object msg7, Object msg8,
                Object msg9, Object msg10)
        {
            if (!isOK)
            {
                BaasException exp = new BaasException(BuildString(msg1, msg2, msg3, msg4, msg5, msg6, msg7, msg8, msg9, msg10));
                throw exp;
            }
        }

        private static String BuildString(params Object[] objs)
        {
            var sb = new StringBuilder();
            foreach (var item in objs)
            {
                sb.Append(item);
            }
            return sb.ToString();
        }

        public static bool isNotEmptyString(string obj)
        {
            return !String.IsNullOrEmpty(obj);
        }

        public static bool isNull(Object obj)
        {
            return obj == null;
        }

        public static bool isNotNull(Object obj)
        {
            return obj != null;
        }
    }
}