﻿using Newtonsoft.Json.Linq;

namespace Com.Justep.Baas.Action
{
    public interface IUserActionUtil
    {
        JObject QueryWithParams(JObject @params, JObject privateParams, JObject publicParams, JObject dbConfig);
        JObject SaveWithParams(JObject @params, JObject privateParams, JObject publicParams, JObject dbConfig);

        string NewString(byte[] bytes, string encoding);
    }
}
