﻿using System.Collections.Generic;

namespace Com.Justep.Baas.Action
{
    using System.Data.Common;
    using System.Transactions;
    using JSONObject = Newtonsoft.Json.Linq.JObject;
    using Table = Com.Justep.Baas.Data.Table;
    using Transform = Com.Justep.Baas.Data.Transform;
    using Util = Com.Justep.Baas.Data.Util;

    public class CRUD
    {
        /// <summary>
        /// 支持sql中使用名字变量，即：":name"形式
        /// </summary>
        /// <param name="jObject">参数</param>
        /// <param name="conn">数据库连接</param>
        /// <returns></returns>
        public static JSONObject Query(JSONObject jObject, DbConnection conn)
        {
            // 获取参数
            string db = jObject.GetString("db");
            string tableName = jObject.GetString("tableName");
            object columns = jObject.GetValue("columns");
            int? limit = jObject.GetInt("limit");
            int? offset = jObject.GetInt("offset");
            string orderBy = jObject.GetString("orderBy");
            string condition = jObject.GetString("condition");
            string filter = jObject.GetString("filter");
            List<string> filters = new List<string>();
            if (!string.IsNullOrEmpty(condition))
            {
                filters.Add(condition);
            }
            if (!string.IsNullOrEmpty(filter))
            {
                filters.Add(filter);
            }
            // 处理主从
            List<DbParameter> sqlParams = new List<DbParameter>();
            // 树形数据
            if (jObject.GetValue("master") != null)
            {
                JSONObject master = jObject.GetValue("master").ToObject<JSONObject>();
                if (master.GetValue("field") != null)
                {
                    filters.Add(master.GetString("field") + " = ?");
                    sqlParams.Add(Util.createParameterByConnection(conn, master.GetString("field"), master.GetString("value")));
                }
            }
            // limit处理，-1取全部
            if (jObject.GetValue("tree") != null)
            {
                //JSONObject treeOption = params.getJSONObject("tree");
            }

            Table table = null;

            try
            {
                conn.Open();
                table = Util.QueryData(conn, tableName, columns, filters, orderBy, sqlParams, offset, limit);
            }
            finally
            {
                conn.Close();
            }
            return Transform.TableToJson(table);
        }

        public static JSONObject save(JSONObject @params, DbConnection conn)
        {
            // 获取参数
            string db = @params.GetString("db");
            JSONObject table = @params.GetValue("table").ToObject<JSONObject>();
            string tableName = @params.GetString("tableName");

            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();

                try
                {
                    if (table != null)
                    {
                        Table userTable = Transform.JsonToTable(table);
                        Util.SaveData(conn, userTable, tableName);
                    }
                    return null;
                }
                catch (DbException e)
                {
                    throw e;
                }
                finally
                {
                    conn.Close();
                    ts.Complete();
                }
            }
        }
    }

}