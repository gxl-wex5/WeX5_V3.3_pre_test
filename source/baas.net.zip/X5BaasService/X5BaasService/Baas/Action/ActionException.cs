﻿using System;

namespace Com.Justep.Baas.Action
{

    public class ActionException : Exception
    {
        private const long serialVersionUID = -8149788234971565128L;

        public ActionException(string msg) : base(msg)
        {
        }

        public ActionException(string msg, Exception exception) : base(msg, exception)
        {
        }
    }

}