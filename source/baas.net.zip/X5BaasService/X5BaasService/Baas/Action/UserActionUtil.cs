﻿
using System.Collections.Generic;
using Com.Justep.Baas.Comm;
using Com.Justep.Baas.Data;

namespace Com.Justep.Baas.Action
{
    using System;
    using System.Data.Common;
    using System.Transactions;
    using MySql.Data.MySqlClient;
    using Newtonsoft.Json.Linq;

    public class UserActionUtil : IUserActionUtil
    {
        private static readonly Dictionary<JObject, DbConnection> ConnectionPool = new Dictionary<JObject, DbConnection>();
        private static readonly object LockThis = new Object();

        public static DbConnection Connection(JObject dbConfig)
        {
            lock (LockThis)
            {
                if (!ConnectionPool.ContainsKey(dbConfig))
                {
                    ConnectionPool.Add(dbConfig, new MySqlConnection("Server=localhost;Uid=root;Pwd=x5;Database=takeout;"));
                }

                return ConnectionPool[dbConfig];
            }
        }

        public JObject SaveWithParams(JObject paramsObject, JObject privateParams, JObject publicParams, JObject dbConfig)
        {
            if (paramsObject == null)
            {
                paramsObject = JObject.Parse("{}");
            }

            // 进行参数处理
            InitActionParams(privateParams, publicParams, paramsObject);

            return Save(paramsObject, Connection(dbConfig));
        }

        public string NewString(byte[] bytes, string encoding)
        {
            return StringHelperClass.NewString(bytes, encoding);
        }

        public JObject QueryWithParams(JObject @params, JObject privateParams, JObject publicParams, JObject dbConfig)
        {
            if (@params == null)
            {
                @params = JObject.Parse("{}");
            }

            // 进行参数处理
            InitActionParams(privateParams, publicParams, @params);

            return CRUD.Query(@params, Connection(dbConfig));
        }

        private static JObject Save(JObject @params, DbConnection conn)
        {
            // 获取参数
            JObject order = (JObject)@params.GetValue("orderTable");
            string orderTableName = "takeout_order";
            JObject user = (JObject)@params.GetValue("userTable");
            string userTableName = "takeout_user";

            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();

                try
                {
                    if (order != null)
                    {
                        Table orderTable = Transform.JsonToTable(order);
                        Util.SaveData(conn, orderTable, orderTableName);
                    }
                    if (user != null)
                    {
                        Table userTable = Transform.JsonToTable(user);
                        Util.SaveData(conn, userTable, userTableName);
                    }
                    return null;
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
                finally
                {
                    conn.Close();
                    ts.Complete();
                }
            }

            return null;
        }

        private static void InitActionParams(JObject privateParams, JObject publicParams, JObject @params)
        {
            foreach (var item in privateParams)
            {
                if (@params[item.Key] == null)
                {
                    @params.Add(item.Key, item.Value);
                }
            }
            foreach (var item in publicParams)
            {
                if (@params[item.Key] == null)
                {
                    @params.Add(item.Key, item.Value);
                }
            }
        }
    }
}
