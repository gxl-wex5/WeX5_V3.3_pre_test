﻿using System;
using System.Reflection;
using Newtonsoft.Json.Linq;

namespace Com.Justep.Baas.Action
{
    using JSONObject = JObject;

    public class ActionUtil
    {
        public static string getRunTimeClassName(string clazz)
        {
            return clazz + "__do";
        }

        public static JSONObject execAction(string actionPath, JSONObject @params)
        {
            ActionDef action = getAction(actionPath);
            Type ownerClass;
            MethodInfo method;
            try
            {

                ownerClass = Type.GetType(action.Clazz);

                // ConstructorInfo magicConstructor = ownerClass.GetConstructor(Type.EmptyTypes);
                // var magicClassObject = magicConstructor.Invoke(new object[] { });

                method = ownerClass.GetMethod(action.Name, @params.ToObject<Type[]>());
                return (JSONObject)(method.Invoke(null, @params.ToObject<Object[]>()));
            }
            catch (TargetException e)
            {
                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);
                throw new ActionException("获取Class[" + action.Clazz + "]失败", e);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);
                throw new ActionException("获取Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
            catch (TargetInvocationException e)
            {
                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);
                throw new ActionException("获取Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
            catch (MethodAccessException e)
            {
                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);
                throw new ActionException("执行Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
            catch (TargetParameterCountException e)
            {
                Console.WriteLine(e.ToString());
                Console.Write(e.StackTrace);
                throw new ActionException("执行Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
        }

        private static string getPackageName(string[] paths)
        {
            if (paths.Length >= 2)
            {
                string name = "";
                for (int i = 0; i < paths.Length - 2; i++)
                {
                    name += (!"".Equals(name) ? "." : "" + paths[i]);
                }
                return name;
            }
            else
            {
                return null;
            }
        }

        private static string getClassName(string[] paths)
        {
            if (paths.Length >= 2)
            {
                string clz = paths[paths.Length - 2];
                if (clz != string.Empty)
                {
                    clz = clz.Substring(0, 1).ToUpper() + clz.Substring(1);
                }
                return getRunTimeClassName(clz);
            }
            else
            {
                return null;
            }
        }

        private static string getActionName(string[] paths)
        {
            if (paths.Length >= 2)
            {
                return paths[paths.Length - 1];
            }
            else
            {
                return null;
            }
        }

        private static ActionDef getAction(string actionPath)
        {
            string[] paths = actionPath.Split('/');
            if (paths.Length >= 2)
            {
                string name = getActionName(paths);
                string clazzName = getClassName(paths);
                string packageName = getPackageName(paths);
                ActionDef action = new ActionDef(name, packageName != string.Empty ? (packageName + "." + clazzName) : clazzName);
                return action;
            }
            else
            {
                return null;
            }
        }

    }

}