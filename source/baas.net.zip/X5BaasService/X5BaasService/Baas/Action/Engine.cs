﻿using System;
using System.Reflection;
using Newtonsoft.Json.Linq;

namespace Com.Justep.Baas.Action
{
    using JSONObject = JObject;

    public class ActionDef
    {
        public string Name;
        public string Clazz;

        public ActionDef(string name, string clz)
        {
            this.Name = name;
            this.Clazz = clz;
        }
    }

    public class Engine
    {
        private static string GetPackageName(string[] paths)
        {
            string excludeNamespace = "baas";

            if (paths.Length >= 2)
            {
                var name = "";
                for (int i = 0; i < paths.Length - 2; i++)
                {
                    if (excludeNamespace != paths[i].ToLower())
                    {
                        name += (!string.IsNullOrEmpty(name) ? "." : "") + paths[i];
                    }
                }

                return name;
            }

            return null;
        }

        private static String GetClassName(String[] paths)
        {
            if (paths.Length >= 2)
            {
                String clz = paths[paths.Length - 2];
                if (!string.IsNullOrEmpty(clz))
                    clz = clz.Substring(0, 1).ToUpper() + clz.Substring(1);
                return GetRunTimeClassName(clz);
            }
            else
                return null;
        }

        private static String GetActionName(String[] paths)
        {
            if (paths.Length >= 2)
            {
                return paths[paths.Length - 1];
            }
            else
                return null;
        }

        private static ActionDef GetAction(String actionPath)
        {
            String[] paths = actionPath.Split('/');
            if (paths.Length >= 2)
            {
                String name = GetActionName(paths);
                String clazzName = GetClassName(paths);
                String packageName = GetPackageName(paths);
                ActionDef action = new ActionDef(name, !string.IsNullOrEmpty(packageName) ? (packageName + "." + clazzName) : clazzName);
                return action;
            }
            else
                return null;
        }

        public static String GetRunTimeClassName(String clazz)
        {
            return clazz + "__do";
        }

        public static JSONObject ExecAction(String actionPath, JSONObject paramObject)
        {
            return ExecAction(actionPath, paramObject, null);
        }

        public static JSONObject ExecAction(String actionPath, JSONObject paramObject, ActionContext context)
        {
            ActionDef action = GetAction(actionPath);
            try
            {
                var ownerClass = Type.GetType(action.Clazz);

                if (ownerClass != null)
                {
                    ownerClass.GetProperty("ActionUtil").SetValue(null, new UserActionUtil());

                    var method = ownerClass.GetMethod(action.Name, BindingFlags.Static | BindingFlags.Public | BindingFlags.IgnoreCase);
                    return (JSONObject) method?.Invoke(null, new[] { (Object)paramObject });
                }

                return null;
            }
            catch (TargetInvocationException e)
            {
                throw new ActionException("获取Class[" + action.Clazz + "]失败", e);
            }
            catch (MethodAccessException e)
            {
                throw new ActionException("获取Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
            catch (ArgumentException e)
            {
                throw new ActionException("执行Class[" + action.Clazz + "] Method[" + action.Name + "]失败", e);
            }
        }
    }
}