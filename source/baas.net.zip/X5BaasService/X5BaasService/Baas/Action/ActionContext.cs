﻿//-----------------------------------------------------------------------
// <copyright file="ActionContext.cs" company="Justep">
//     Copyright Justep Co., LTD. All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace Com.Justep.Baas.Action
{
	using System;
	using System.Collections.Generic;
	using JSONObject = Newtonsoft.Json.Linq.JObject;

	public class ActionContext
	{
		public const String REQUEST = "request"; 
		public const String RESPONSE = "response"; 

		private readonly IDictionary<string, object> values = new Dictionary<string, object>();

		private JSONObject databaseConfig;

		public ActionContext()
		{
		}

		public ActionContext(JSONObject databaseConfig)
		{
			if (databaseConfig == null)
			{
				throw new ArgumentNullException(nameof(databaseConfig));
			}

			this.databaseConfig = databaseConfig;
		}

		public virtual object Get(string key)
		{
			return values[key];
		}

		public virtual void Put(string key, object value)
		{
			values[key] = value;
		}

		public virtual void Clear()
		{
			values.Clear();
		}

		public virtual bool ContainsKey(string key)
		{
			return values.ContainsKey(key);
		}
	}
}