﻿using Justep.Baas.Data;
using Justep.Baas.Service;
using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System.Data.Common;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// X5 Baas 服务入口
/// </summary>
public class X5BaasService : WebService
{

    private static DbConnection CreateConnection()
    {
        // 下面是目前可识别的数据库链接方式，可以通过扩展DatabaseType.cs中的DatabaseTypeHelper类以支持其他数据库
        // return new OracleConnection("data source=orcl;user id=x5sys;password=x5;persist security info=false;");
        // return new SqlConnection("server=localhost\\SQLEXPRESS2005;database=X5Sys;uid=sa;pwd=203010");
        return new MySqlConnection("Server=localhost;Uid=root;Pwd=x5;Database=takeout;");
    }

    [WebMethod]
    public void HelloWorld()
    {
        HttpContext.Current.Response.ContentType = "application/json;charset=utf-8";
        // 支持跨域请求，正式部署时"*"应改为UIServer的地址
        HttpContext.Current.Response.AddHeader("Access-Control-Allow-Origin", "*");

        DbConnection conn = CreateConnection();
        conn.Open();
        try
        {
            // 执行数据库查询
            DbCommand comm = conn.CreateCommand();
            comm.CommandText = "SELECT * FROM takeout_food u";
            DbDataReader data = comm.ExecuteReader();
            // 转换成Table对象
            Table table = Transform.DataToTable(data, "", null);
            // 转换成JSON
            JObject json = Transform.TableToJson(table);
            // 输出JSON
            HttpContext.Current.Response.Write(json.ToString());
        }
        finally
        {
            conn.Close();
        }
    }

    /// <summary>
    /// X5 Baas Demo案例的服务入口
    /// </summary>
    [WebMethod]
    public void demo()
    {
        HttpResponse response = HttpContext.Current.Response;
        response.ContentType = "text/html;charset=utf-8";
        // 支持跨域请求，正式部署时"*"应改为UIServer的地址
        response.AddHeader("Access-Control-Allow-Origin", "*");

        DbConnection conn = CreateConnection();
        DemoService.Execute(conn);
    }

    /// <summary>
    /// X5 Baas 外卖案例的服务入口
    /// </summary>
    [WebMethod]
    public void takeout()
    {
        HttpResponse response = HttpContext.Current.Response;
        response.ContentType = "text/html;charset=utf-8";
        // 支持跨域请求，正式部署时"*"应改为UIServer的地址
        response.AddHeader("Access-Control-Allow-Origin", "*");

        DbConnection conn = CreateConnection();
        TakeoutService.Execute(conn);
    }

}
