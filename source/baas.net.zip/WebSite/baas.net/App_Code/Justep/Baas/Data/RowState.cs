﻿using System;
using System.Collections.Generic;

namespace Justep.Baas.Data
{
    /// <summary>
    /// Table的行状态枚举
    /// </summary>
    public enum RowState
    {
        NONE, NEW, EDIT, DELETE
    }

    /// <summary>
    /// Table的行状态枚举辅助类，用于数据转换
    /// </summary>
    public static class RowStateHelper
    {
        public static RowState Parse(string str)
        {
            return Util.IsEmptyString(str) ? RowState.NONE : (RowState) Enum.Parse(typeof(RowState), str.ToUpper());
        }

        public static string ToString(RowState state)
        {
            return state.ToString().ToLower();
        }
    }
}