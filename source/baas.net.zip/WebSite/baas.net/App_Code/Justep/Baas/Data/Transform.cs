﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Globalization;
using System.Linq;

namespace Justep.Baas.Data
{
    /// <summary>
    /// 转换工具类，实现Table对象与JSON、数据集之间的转换
    /// </summary>
	public static class Transform
	{
		private static readonly string DATE_FORMAT = "yyyy-MM-dd";
        private static readonly string TIME_FORMAT = "hh:mm:ss.fff";
		private static readonly string DATETIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.fff'Z'";

		private const string USER_DATA = "userdata";
		private const string ID_COLUMN_NAME = "idColumnName";
		private const string ID_COLUMN_TYPE = "idColumnType";
		private const string COLUMN_NAMES = "relationAlias";
		private const string COLUMN_TYPES = "relationTypes";

		private const string TABLE_TOTAL = "sys.count";
		private const string TABLE_OFFSET = "sys.offset";

		private const string ROWS = "rows";
		private const string ROW_STATE = "recordState";
		private const string ROW_ID = "id";
		private const string ROW_VALUE = "value";
		private const string ROW_OLD_VALUE = "originalValue";
		private const string ROW_VALUE_CHANGED = "changed";
		private const int ROW_VALUE_ISCHANGED = 1;

		/// <summary>
		/// 将.w中data.toJson()的数据转换为Table 
        /// </summary>
		public static Table JsonToTable(string json)
		{
			return JsonToTable(JObject.Parse(json));
		}

		/// <summary>
		/// 将.w中data.toJson()的数据转换为Table 
        /// </summary>
		public static Table JsonToTable(JObject json)
		{
			JObject jsUserData = (JObject)json.GetValue(USER_DATA);

            // 构造列定义
			IDictionary<string, DataType> columns = new SortedDictionary<string, DataType>();
			string idColumn = (string)jsUserData.GetValue(ID_COLUMN_NAME);
			string idColumnType = (string)jsUserData.GetValue(ID_COLUMN_TYPE);
			if (idColumn != null && idColumnType != null)
			{
				columns[idColumn] = DataTypeHelper.Parse(idColumnType);
			}

			string[] names = ((string)jsUserData.GetValue(COLUMN_NAMES)).Split(',');
			string[] types = ((string)jsUserData.GetValue(COLUMN_TYPES)).Split(',');
			for (int i = 0, len = names.Length; i < len; i++)
			{
				columns[names[i]] = DataTypeHelper.Parse(types[i]);
			}

            // 创建Table
			Table table = new Table(columns);

			if (idColumn != null)
			{
				table.IDColumn = idColumn;
			}
			if (jsUserData.GetValue(TABLE_TOTAL) != null)
			{
				table.Total = (int?)jsUserData.GetValue(TABLE_TOTAL);
			}
			if (jsUserData.GetValue(TABLE_OFFSET) != null)
			{
				table.Offset = (int?)jsUserData.GetValue(TABLE_OFFSET);
			}

            // 转换行数据
			JArray jsRows = (JArray)json.GetValue(ROWS);
			IList<Row> rows = new List<Row>();
			foreach(JObject jsRow in jsRows)
			{
				Row row = JsonToRow(table, jsRow);
				rows.Add(row);
			}
			table.AppendRows(rows);

			return table;
		}

		/// <summary>
		/// 将Table转换为.w中data可以加载的JSON数据结构 
        /// </summary>
		public static JObject TableToJson(Table table)
		{
			return TableToJson(table, null);
		}

        /// <summary>
        /// 将Table转换为.w中data可以加载的树形JSON数据结构，必须指定Table的idColumn属性，由parentColumn与Table的idColumn构成父子树
        /// </summary>
        public static JObject TableToTreeJson(Table table, string parentColumn)
		{
			if (table.IDColumn == null || parentColumn == null)
			{
				throw new Exception("转换树形结构必须指定Table的idColumn属性和parentColumn参数");
			}
			return TableToJson(table, parentColumn);
		}

		private static JObject TableToJson(Table table, string parentColumn)
		{
			JObject jsTable = new JObject();
			jsTable.Add("@type", "table");

            // 转换元信息
			JObject jsUserData = new JObject();
            if (table.Total != null)
            {
    			jsUserData.Add(TABLE_TOTAL, table.Total);
            }
            if (table.Offset != null)
            {
                jsUserData.Add(TABLE_OFFSET, table.Offset);
            }

            string idColumn = table.IDColumn;
			if (idColumn != null)
			{
				jsUserData.Add(ID_COLUMN_NAME, idColumn);
				jsUserData.Add(ID_COLUMN_TYPE, DataTypeHelper.ToString(table.GetColumnType(idColumn)));
			}
            jsUserData.Add(COLUMN_NAMES, Util.ArrayJoin(table.ColumnNames.ToArray(), "{0}", ","));
            jsUserData.Add(COLUMN_TYPES, Util.ArrayJoin(table.ColumnTypes.ToArray(), "{0}", ","));
			jsTable.Add(USER_DATA, jsUserData);

            // 转换行数据
			JArray jsRows = new JArray();
			if (parentColumn == null)
			{
				foreach (Row row in table.Rows)
				{
					JObject jsRow = RowToJson(table, row);
					jsRows.Add(jsRow);
				}
			}
			else
			{
                // 构造成树形
				IDictionary<object, JObject> parentMap = new Dictionary<object, JObject>();
				IDictionary<object, IList<JObject>> childrenMap = new Dictionary<object, IList<JObject>>();
				foreach (Row row in table.Rows)
				{
					JObject jsRow = RowToJson(table, row);

					object idValue = row.GetValue(idColumn);
					object parentValue = row.GetValue(parentColumn);

					// find parent
					if (parentValue != null && parentMap.ContainsKey(parentValue))
					{
						JObject parentRow = parentMap[parentValue];
						AddJsonRowChild(parentRow, jsRow);
					}
					else
					{
						jsRows.Add(jsRow);
					}
					// find children
					if (childrenMap.ContainsKey(idValue))
					{
						IList<JObject> children = childrenMap[idValue];
						foreach (JObject childRow in children)
						{
							AddJsonRowChild(jsRow, childRow);
							jsRows.Remove(childRow);
						}
					}
					parentMap[idValue] = jsRow;
					if (parentValue != null)
					{
						if (!childrenMap.ContainsKey(parentValue))
						{
							childrenMap[parentValue] = new List<JObject>();
						}
						childrenMap[parentValue].Add(jsRow);
					}
				}
			}
			jsTable.Add(ROWS, jsRows);

			return jsTable;
		}

		private static void AddJsonRowChild(JObject parent, JObject child)
		{
			if (parent.GetValue(ROWS) == null)
			{
				parent.Add(ROWS, new JArray());
			}
			((JArray)parent.GetValue(ROWS)).Add(child);
		}

		private static Row JsonToRow(Table table, JObject jsRow)
		{
			IDictionary<string, ColumnValue> values = new Dictionary<string, ColumnValue>();
			RowState state = RowState.NONE;

			JObject jsUserData = (JObject)jsRow.GetValue(USER_DATA);
			if (jsUserData != null)
			{
				state = RowStateHelper.Parse((string)jsUserData.GetValue(ROW_STATE));
				if (jsUserData.GetValue(ROW_ID) != null)
				{
					string idColumn = table.IDColumn;
					ColumnValue value = JsonToColumnValue((JObject)jsUserData.GetValue(ROW_ID), table.GetColumnType(idColumn));
					values[idColumn] = value;
				}
			}
			foreach (string name in table.ColumnNames)
			{
				if (jsRow.GetValue(name) != null)
				{
					ColumnValue value = JsonToColumnValue((JObject)jsRow.GetValue(name), table.GetColumnType(name));
					values[name] = value;
				}
			}

			return new Row(values, state);
		}

		private static JObject RowToJson(Table table, Row row)
		{
			JObject jsRow = new JObject();

			JObject jsUserData = new JObject();
			jsUserData.Add(ROW_STATE, RowStateHelper.ToString(row.State));

			string idColumn = table.IDColumn;
			if (idColumn != null)
			{
				jsUserData.Add(ROW_ID, ColumnValueToJson(row.GetColumnValue(idColumn), table.GetColumnType(idColumn)));
			}

            jsRow.Add(USER_DATA, jsUserData);

			foreach (string name in table.ColumnNames)
			{
				jsRow.Add(name, ColumnValueToJson(row.GetColumnValue(name), table.GetColumnType(name)));
			}

			return jsRow;
		}

		private static ColumnValue JsonToColumnValue(JObject jsColumnValue, DataType type)
		{
			object value = JsonToValue(jsColumnValue.GetValue(ROW_VALUE), type);
			object oldValue = JsonToValue(jsColumnValue.GetValue(ROW_OLD_VALUE), type);
			int? changed = (int?)jsColumnValue.GetValue(ROW_VALUE_CHANGED);
			return new ColumnValue(value, oldValue, ROW_VALUE_ISCHANGED.Equals(changed));
		}

		private static JObject ColumnValueToJson(ColumnValue value, DataType type)
		{
			JObject jsColumnValue = new JObject();
			if (value != null)
			{
                object jValue = ValueToJson(value.Value, type);
                jsColumnValue.Add(ROW_VALUE, jValue == null ? null : JToken.FromObject(jValue));
				if (value.Changed)
				{
                    object jOldValue = ValueToJson(value.OldValue, type);
                    jsColumnValue.Add(ROW_OLD_VALUE, jOldValue == null ? null : JToken.FromObject(jOldValue));
					jsColumnValue.Add(ROW_VALUE_CHANGED, ROW_VALUE_ISCHANGED);
				}
			}
			return jsColumnValue;
		}

		private static object JsonToValue(JToken jsValue, DataType type)
		{
			if (jsValue == null)
			{
				return null;
			}
			switch (type)
			{
			case DataType.STRING:
                return jsValue.ToObject(Type.GetType("System.String"));
            case DataType.INTEGER:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Int32]"));
			case DataType.LONG:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Int64]"));
            case DataType.FLOAT:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Single]"));
            case DataType.DOUBLE:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Double]"));
            case DataType.DECIMAL:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Decimal]"));
            case DataType.BOOLEAN:
                return jsValue.ToObject(Type.GetType("System.Nullable`1[System.Boolean]"));
            case DataType.DATE:
				return jsValue.ToObject(Type.GetType("System.Nullable`1[System.DateTime]"));
            case DataType.TIME:
                return jsValue.ToObject(Type.GetType("System.Nullable`1[System.DateTime]"));
            case DataType.DATETIME:
                return jsValue.ToObject(Type.GetType("System.Nullable`1[System.DateTime]"));
            }
            return jsValue;
		}

		private static object ValueToJson(object value, DataType type)
		{
			if (value == null)
			{
				return null;
			}
			switch (type)
			{
			case DataType.STRING:
			case DataType.INTEGER:
			case DataType.LONG:
			case DataType.FLOAT:
			case DataType.DOUBLE:
			case DataType.BOOLEAN:
				break;
			case DataType.DECIMAL:
				return value.ToString();
			case DataType.DATE:
				return ((DateTime)value).ToString(DATE_FORMAT);
			case DataType.TIME:
                return ((DateTime)value).ToString(TIME_FORMAT);
            case DataType.DATETIME:
			    return ((DateTime)value).ToString(DATETIME_FORMAT);
			}
			return value;
		}

        /// <summary>
        /// 通过IDataReader转换SQL数据为Table 
        /// </summary>
        /// <param name="columns"> 指定要转换的列，以逗号分隔，如果为空则转换所有列；columns不仅用于限定转换的列范围，同时也用于指定转换列名的大小写 </param>
        /// <param name="count"> 行数，如果为null或小于零，则转换所有行 </param>
        public static Table DataToTable(IDataReader data, string columns, int? count)
		{
			Table table = CreateTableByData(data, columns);
			LoadRowsFromData(table, data, count);
			return table;
		}

        /// <summary>
        /// 按IDataReader的列定义生成Table 
        /// </summary>
        /// <param name="columns"> 指定要转换的列，以逗号分隔，如果为空则转换所有列；columns不仅用于限定转换的列范围，同时也用于指定转换列名的大小写 </param>
        public static Table CreateTableByData(IDataReader data, string columns)
		{
			// 构造一个列名的映射，用于忽略列名大小写敏感
			IDictionary<string, string> columnNameMap = null;
			if (columns != null && columns.Trim().Length > 0)
			{
				columnNameMap = new Dictionary<string, string>();
				foreach (string column in columns.Split(','))
				{
					columnNameMap[column.ToUpper()] = column;
				}
			}

            IDictionary<string, DataType> tableColumns = new SortedDictionary<string, DataType>();
            for (int i = 0; i < data.FieldCount; i++)
            {
                string name = data.GetName(i);
                if (columnNameMap == null || columnNameMap.ContainsKey(name.ToUpper()))
                {
                    if (columnNameMap != null)
                    {
                        name = columnNameMap[name.ToUpper()];
                    }
                    DataType type = DataTypeHelper.ParseSQLType(data.GetFieldType(i));
                    tableColumns[name] = type;
                }
            }

            return new Table(tableColumns);
		}

        /// <summary>
        /// 通过IDataReader加载SQL数据到Table 
        /// </summary>
        /// <param name="count"> 行数，如果为null或小于零，则加载所有行 </param>
        public static void LoadRowsFromData(Table table, IDataReader data, int? count)
		{
            // 构造一个列名的映射，用于忽略列名大小写敏感
            IDictionary<string, string> tableNameMap = new Dictionary<string, string>();
            foreach (string column in table.ColumnNames)
            {
                tableNameMap[column.ToUpper()] = column;
            }
            // 构造Table列名与Reader列序号的映射
            IDictionary<string, int> columnsMap = new Dictionary<string, int>();
            for (int i = 0; i < data.FieldCount; i++) {
                string name = data.GetName(i);
                if (tableNameMap.ContainsKey(name.ToUpper()))
                {
                    columnsMap.Add(tableNameMap[name.ToUpper()], i);
                }
            }

            int j = 0;
            while (data.Read() && (count == null || count < 0 || j < count))
            {
                table.AppendRow(DataToRow(table, data, RowState.NONE, columnsMap));
                j++;
            }
		}

		private static Row DataToRow(Table table, IDataReader rs, RowState state, IDictionary<string, int> columnsMap)
		{
            IDictionary<string, ColumnValue> values = new Dictionary<string, ColumnValue>();
            foreach(string name in columnsMap.Keys) {
                int fieldIndex = columnsMap[name];
                object value = null;
                DataType type = table.GetColumnType(name);
                switch (type)
                {
                    case DataType.STRING:
                        value = rs.IsDBNull(fieldIndex) ? null : rs.GetString(fieldIndex);
                        break;
                    case DataType.INTEGER:
                        value = rs.IsDBNull(fieldIndex) ? null : (int?)int.Parse(rs.GetValue(fieldIndex).ToString());
                        break;
                    case DataType.LONG:
                        value = rs.IsDBNull(fieldIndex) ? null : (long?)long.Parse(rs.GetValue(fieldIndex).ToString());
                        break;
                    case DataType.FLOAT:
                        value = rs.IsDBNull(fieldIndex) ? null : (double?)double.Parse(rs.GetValue(fieldIndex).ToString());
                        break;
                    case DataType.DOUBLE:
                        value = rs.IsDBNull(fieldIndex) ? null : (double?)double.Parse(rs.GetValue(fieldIndex).ToString());
                        break;
                    case DataType.DECIMAL:
                        value = rs.IsDBNull(fieldIndex) ? null : (decimal?)rs.GetDecimal(fieldIndex);
                        break;
                    case DataType.BOOLEAN:
                        value = rs.IsDBNull(fieldIndex) ? null : (bool?)("1".Equals(rs.GetValue(fieldIndex).ToString()) || "true".Equals(rs.GetValue(fieldIndex).ToString().ToLower()));
                        break;
                    case DataType.DATE:
                        value = rs.IsDBNull(fieldIndex) ? null : (DateTime?)rs.GetDateTime(fieldIndex);
                        break;
                    case DataType.TIME:
                        value = rs.IsDBNull(fieldIndex) ? null : (DateTime?)DateTime.Parse(rs.GetValue(fieldIndex).ToString());
                        break;
                    case DataType.DATETIME:
                        value = rs.IsDBNull(fieldIndex) ? null : (DateTime?)rs.GetDateTime(fieldIndex);
                        break;
                }
                values[name] = new ColumnValue(value);
            }
			return new Row(values, state);
		}

        /// <summary>
        /// 按来自前端Data组件的列定义，转换SQL数据为Table 
        /// </summary>
        /// <param name="columnsDefine"> 来自前端Data的列定义 </param>
        /// <param name="count"> 行数，如果为null或小于零，则转换所有行 </param>
        public static Table DataToTable(IDataReader data, JObject columnsDefine, int? count)
		{
			Table table = CreateTableByColumnsDefine(columnsDefine);
			LoadRowsFromData(table, data, count);
			return table;
		}

		/// <summary>
		/// 按来自前端Data组件的列定义生成Table对象 
        /// </summary>
		/// <param name="columnsDefine">
		public static Table CreateTableByColumnsDefine(JObject columnsDefine)
		{
			IDictionary<string, DataType> columns = new SortedDictionary<string, DataType>();
			foreach (JToken child in columnsDefine.Children())
			{
				JObject columnDefine = (JObject)((JProperty)child).Value;
				columns.Add((string)columnDefine.GetValue("name"), DataTypeHelper.Parse((string)columnDefine.GetValue("type")));
			}
			Table table = new Table(columns);
			return table;
		}

	}

}