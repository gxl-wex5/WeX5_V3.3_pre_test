﻿using Justep.Baas.Data;
using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Transactions;
using System.Web;

namespace Justep.Baas.Service
{

    /// <summary>
    /// X5 Baas Demo案例的实现类，服务入口参见X5BassService.demo
    /// </summary>
    public static class DemoService
    {

        private static string TABLE_TAKEOUT_ORDER = "takeout_order";
        private static string TABLE_TAKEOUT_REGION = "takeout_region";
        private static string TABLE_TAKEOUT_USER = "takeout_user";

        public static void Execute(DbConnection conn)
        {
            string action = HttpContext.Current.Request.Params["action"];
            if ("queryOrder".Equals(action))
            {
                QueryOrder(conn);
            } else if ("saveOrder".Equals(action))
            {
                SaveOrder(conn);
            }
            else if ("queryRegionTree".Equals(action))
            {
                QueryRegionTree(conn);
            }
            else if ("queryRegionTreeByParent".Equals(action))
            {
                QueryRegionTreeByParent(conn);
            }
            else if ("queryUser".Equals(action))
            {
                QueryUser(conn);
            }
            else if ("saveUser".Equals(action))
            {
                SaveUser(conn);
            }
            else if ("saveMasterDetail".Equals(action))
            {
                SaveMasterDetail(conn);
            }

        }

        private static void QueryOrder(DbConnection conn)
        {
            conn.Open();
            try
            {
                // 参数序列化
                JObject parameters = JObject.Parse(HttpContext.Current.Request.Params["params"]);

                // 获取参数
                object columns = parameters.GetValue("columns"); // 列定义
                int? limit = (int?)parameters.GetValue("limit"); // 分页查询的行数
                int? offset = (int?)parameters.GetValue("offset"); // 分页查询的行偏移
                string search = (string)parameters.GetValue("search"); // 检索关键字

                // 存放SQL中的参数值
                List<DbParameter> sqlParams = new List<DbParameter>();
                // 存放SQL中的过滤条件
                List<string> filters = new List<string>();
                if (!Util.IsEmptyString(search))
                {
                    // 增加过滤条件
                    filters.Add(string.Format("fUserName LIKE {0} OR fPhoneNumber LIKE {0} OR fAddress LIKE {0} OR fContent LIKE {0}", DatabaseTypeHelper.GetParamPrefix(conn) + "search"));
                    // 检索关键字中如果没有%，则前后自动加%
                    search = (search.IndexOf("%") != -1) ? search : "%" + search + "%";
                    // 增加检索参数
                    sqlParams.Add(Util.createParameterByConnection(conn, "search", search));
                }

                // 按用户ID过滤，用于主从数据示例
                string userID = (string)parameters.GetValue("userID");
                if (!Util.IsEmptyString(userID))
                {
                    filters.Add("fUserID = " + DatabaseTypeHelper.GetParamPrefix(conn) + "userID");
                    sqlParams.Add(Util.createParameterByConnection(conn, "userID", userID));
                }

                // 执行单表数据查询，返回Table
                Table table = Util.QueryData(conn, TABLE_TAKEOUT_ORDER, columns, filters, "fCreateTime DESC", sqlParams, offset, limit);
                // 输出Table的JSON格式
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                // 必须关闭数据源连接
                conn.Close();
            }
        }

        // 保存订单
        private static void SaveOrder(DbConnection conn) {
            // 参数序列化
            JObject parameters = JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            JObject data = (JObject)parameters.GetValue("data"); // 订单数据的JSON格式

            // JSON转换Table
            Table table = Transform.JsonToTable(data);

            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();
                try
                {
                    // 保存Table
                    Util.SaveData(conn, table, TABLE_TAKEOUT_ORDER);
                } finally {
                    // 必须关闭数据源连接
                    conn.Close();
                }
                // 提交事务
                ts.Complete();
            }
        }
        private static void QueryRegionTree(DbConnection conn)
        {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns");

            conn.Open();
            try
            {
                // 获取数据
                Table table = Util.QueryData(conn, TABLE_TAKEOUT_REGION, columns, null, "fID ASC", null, null, null);

                // 转换为树形数据
                table.IDColumn = "fID";
                JObject tableJSON = Transform.TableToTreeJson(table, "fParentID");
                // 输出返回结果 
                HttpContext.Current.Response.Write(tableJSON.ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void QueryRegionTreeByParent(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns");
            int? limit = (int?)parameters.GetValue("limit");
            int? offset = (int?)parameters.GetValue("offset");
            string parent = (string)parameters.GetValue("parent");

            conn.Open();
            try
            {
                // 存放SQL中的参数值
                List<DbParameter> sqlParams = new List<DbParameter>();
                // 构造过滤条件
                List<string> filters = new List<string>();
                // 构造父过滤条件
                if (Util.IsEmptyString(parent))
                {
                    filters.Add("fParentID is null");
                }
                else
                {
                    filters.Add("fParentID = " + DatabaseTypeHelper.GetParamPrefix(conn) + "parent");
                    sqlParams.Add(Util.createParameterByConnection(conn, "parent", parent));
                }

                // 获取数据
                Table table = Util.QueryData(conn, TABLE_TAKEOUT_REGION, columns, filters, "fID ASC", sqlParams, offset, limit);
                // 输出返回结果 
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void QueryUser(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns"); // 列定义
            int? limit = (int?)parameters.GetValue("limit");
            int? offset = (int?)parameters.GetValue("offset");
            string search = (string)parameters.GetValue("search");

            conn.Open();
            try
            {
                // 存放SQL中的参数值
                List<DbParameter> sqlParams = new List<DbParameter>();
                // 构造where
                string sqlWhere = "";
                if (!Util.IsEmptyString(search))
                {
                    sqlWhere = string.Format(" WHERE (u.fID LIKE {0} OR u.fName LIKE {0} OR u.fPhoneNumber LIKE {0} OR u.fAddress LIKE {0}) ", DatabaseTypeHelper.GetParamPrefix(conn) + "search");
                    // 多个问号参数的值
                    search = (search.IndexOf("%") != -1) ? search : "%" + search + "%";
                    sqlParams.Add(Util.createParameterByConnection(conn, "search", search));
                }

                // 复杂查询
                string sql = "SELECT u.fID, u.fName, u.fPhoneNumber, u.fAddress, COUNT(ord.fID) AS orderCount "
                                + " FROM takeout_user u "
                                + " 	LEFT JOIN takeout_order ord ON u.fID = ord.fUserID "
                                + sqlWhere
                                + " GROUP BY u.fID, u.fName, u.fPhoneNumber, u.fAddress ";

                Table table = table = Util.QueryData(conn, sql, sqlParams, columns, offset, limit);
                if (offset != null && offset.Equals(0))
                {
                    string sqlTotal = "SELECT COUNT(*) FROM takeout_user u " + sqlWhere;
                    object total = Util.GetValueBySQL(conn, sqlTotal, sqlParams);
                    table.Total = int.Parse(total.ToString());
                }
                // 输出返回结果 
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void SaveUser(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);
            // 获取参数
            JObject data = (JObject)parameters.GetValue("data");

            // 转换Table
            Table table = Transform.JsonToTable(data);

            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();
                try
                {
                    // 排除不能保存的列
                    List<string> columns = new List<string>();
                    columns.AddRange(table.ColumnNames);
                    columns.Remove("orderCount");
                    // 保存Table
                    Util.SaveData(conn, table, TABLE_TAKEOUT_USER, columns);
                }
                finally
                {
                    conn.Close();
                }
                ts.Complete();
            }
        }

        private static void SaveMasterDetail(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);
            // 获取参数
            JObject userData = (JObject)parameters.GetValue("userData");
            JObject orderData = (JObject)parameters.GetValue("orderData");

            // 转换Table
            Table userTable = Transform.JsonToTable(userData);
            Table orderTable = Transform.JsonToTable(orderData);
            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();
                try
                {
                    // 排除不能保存的列
                    List<string> userColumns = new List<string>();
                    userColumns.AddRange(userTable.ColumnNames);
                    userColumns.Remove("orderCount");

                    // 一个事务内同时保存多张表
                    Util.SaveData(conn, userTable, TABLE_TAKEOUT_USER, userColumns);
                    Util.SaveData(conn, orderTable, TABLE_TAKEOUT_ORDER);
                }
                finally
                {
                    conn.Close();
                }
                ts.Complete();
            }
        }
    }
	
}