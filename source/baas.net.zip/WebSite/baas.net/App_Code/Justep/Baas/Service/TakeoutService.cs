﻿using Justep.Baas.Data;
using MySql.Data.MySqlClient;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.OracleClient;
using System.Data.SqlClient;
using System.Linq;
using System.Transactions;
using System.Web;

namespace Justep.Baas.Service
{
    /// <summary>
    /// Takeout 的摘要说明
    /// </summary>
    public static class TakeoutService
    {
        private static string TABLE_TAKEOUT_FOOD = "takeout_food";
        private static string TABLE_TAKEOUT_ORDER = "takeout_order";
        // private static string TABLE_TAKEOUT_REGION = "takeout_region";
        private static string TABLE_TAKEOUT_USER = "takeout_user";

        public static void Execute(DbConnection conn)
        {
            string action = HttpContext.Current.Request.Params["action"];
            if ("queryFood".Equals(action))
            {
                QueryFood(conn);
            }
            else if ("queryUser".Equals(action))
            {
                QueryUser(conn);
            }
            else if ("queryOrder".Equals(action))
            {
                QueryOrder(conn);
            }
            else if ("save".Equals(action))
            {
                Save(conn);
            }

        }

         private static void QueryFood(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns");
            int? limit = (int?)parameters.GetValue("limit");
            int? offset = (int?)parameters.GetValue("offset");

            conn.Open();
            try
            {
                Table table = Util.QueryData(conn, TABLE_TAKEOUT_FOOD, columns, null, "fID ASC", null, offset, limit);
                // 输出返回结果 
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void QueryUser(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns");
            string id = (string)parameters.GetValue("id");

            conn.Open();
            try
            {

                List<DbParameter> sqlParams = new List<DbParameter>();
                List<string> filters = new List<string>();
                filters.Add("fID = " + DatabaseTypeHelper.GetParamPrefix(conn) + "id");
                sqlParams.Add(Util.createParameterByConnection(conn, "id", id));

                Table table = Util.QueryData(conn, TABLE_TAKEOUT_USER, columns, filters, "fID ASC", sqlParams, null, null);
                // 输出返回结果 
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void QueryOrder(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);

            // 获取参数
            object columns = parameters.GetValue("columns");
            int? limit = (int?)parameters.GetValue("limit");
            int? offset = (int?)parameters.GetValue("offset");
            string search = (string)parameters.GetValue("search");

            conn.Open();
            try
            {
                // 存放SQL中的参数值
                List<DbParameter> sqlParams = new List<DbParameter>();
                // 构造过滤条件
                List<string> filters = new List<string>();
                if (!Util.IsEmptyString(search))
                {
                    filters.Add(String.Format("fUserName LIKE {0} OR fPhoneNumber LIKE {0} OR fAddress LIKE {0} OR fContent LIKE {0}", DatabaseTypeHelper.GetParamPrefix(conn) + "search"));
                    // 多个问号参数的值
                    search = (search.IndexOf("%") != -1) ? search : "%" + search + "%";
                    sqlParams.Add(Util.createParameterByConnection(conn, "search", search));
                }

                // 按用户ID过滤
                string userID = (string)parameters.GetValue("userID");
                if (!Util.IsEmptyString(userID))
                {
                    filters.Add("fUserID = " + DatabaseTypeHelper.GetParamPrefix(conn) + "userID");
                    sqlParams.Add(Util.createParameterByConnection(conn, "userID", userID));
                }

                Table table = Util.QueryData(conn, TABLE_TAKEOUT_ORDER, columns, filters, "fCreateTime DESC", sqlParams, offset, limit);
                // 输出返回结果 
                HttpContext.Current.Response.Write(Transform.TableToJson(table).ToString());
            }
            finally
            {
                conn.Close();
            }
        }

        private static void Save(DbConnection conn) {
            // 参数序列化
            JObject parameters = (JObject)JObject.Parse(HttpContext.Current.Request.Params["params"]);
            // 获取参数
            JObject userData = (JObject)parameters.GetValue("userData");
            JObject orderData = (JObject)parameters.GetValue("orderData");

            using (TransactionScope ts = new TransactionScope())
            {
                conn.Open();
                try
                {
                    if (userData != null)
                    {
                        Table userTable = Transform.JsonToTable(userData);
                        Util.SaveData(conn, userTable, TABLE_TAKEOUT_USER);
                    }
                    if (orderData != null)
                    {
                        Table orderTable = Transform.JsonToTable(orderData);
                        Util.SaveData(conn, orderTable, TABLE_TAKEOUT_ORDER);
                    }

                }
                finally
                {
                    conn.Close();
                }
                ts.Complete();
            }
        }
    }
}
