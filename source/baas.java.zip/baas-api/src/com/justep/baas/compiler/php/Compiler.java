package com.justep.baas.compiler.php;

import com.justep.baas.compiler.BaseCompiler;
import com.justep.baas.compiler.CompileContext;

public class Compiler extends BaseCompiler {

	public Compiler(String compileLang, String modelDir, String outputDir, boolean outSource) {
		super(compileLang, modelDir, outputDir, outSource);
		// TODO 自动生成的构造函数存根
	}

	@Override
	protected CompileContext createContext(String modelDir, String outputDir, boolean outSource) {
		// TODO 自动生成的方法存根
		return null;
	}

	@Override
	public void compile() {
		// TODO 自动生成的方法存根

	}

}
