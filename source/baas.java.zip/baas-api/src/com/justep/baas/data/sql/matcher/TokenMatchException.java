package com.justep.baas.data.sql.matcher;

public class TokenMatchException extends RuntimeException {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 5256774387480472140L;

	public TokenMatchException(){
		super();
	}
	public TokenMatchException(String msg){
		super(msg);
	}
}
