package com.justep.baas.data.sql.matcher;

import com.justep.baas.data.sql.token.CharStream;
import com.justep.baas.data.sql.token.Token;

public abstract class TokenMatcher {

	public abstract Token match(CharStream stream);

}
